
# print(clg.ensemble_prediction(4)